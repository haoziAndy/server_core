#if __has_feature(objc_arc)
#error "C files shouldn't be ARC'd!"
#endif

void c_fun() {}

