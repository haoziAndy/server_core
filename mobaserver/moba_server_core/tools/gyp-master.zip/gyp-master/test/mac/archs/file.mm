MyInt f() { return 0; }
