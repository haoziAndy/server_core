#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Thing : NSObject

+ (instancetype)thing;

- (void)sayHello;

@end
