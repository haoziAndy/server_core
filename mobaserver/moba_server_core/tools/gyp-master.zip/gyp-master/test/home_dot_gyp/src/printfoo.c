#include <stdio.h>

int main(void)
{
  printf("FOO is %s\n", FOO);
  return 0;
}
